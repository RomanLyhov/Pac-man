# pacman_python_pygame

```
-------------------------------------------------------------------------------
Language                     files          blank        comment           code
-------------------------------------------------------------------------------
Python                           1            117              1            479
-------------------------------------------------------------------------------
```


note: part II updated without rewriting part I so it's still usable with the original article


![pacman13](https://user-images.githubusercontent.com/5726108/209607270-dd432585-663a-459f-bef8-39262d5dbfe6.gif)
